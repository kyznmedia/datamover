import psycopg2
import psycopg2.extensions
import os
import requests
import time
from datetime import datetime, timedelta

def buzzsumo(topic):
    base_url = 'http://api.buzzsumo.com/search/articles.json'
    site_endpoint = base_url + '?api_key=' + os.environ['BUZZSUMO_KEY'] + '&q=' + topic
    r = requests.get(site_endpoint)
    if r.status_code == 200:
        return r
    else:
        print('Error connecting to server:' + str(r.status_code))

# object helper
def returnVal(obj, name):
    try:
        data = obj[name]
        return (data[:9000] + '..') if len(data) > 9000 else data
    except:
        return None

def main():
    # Connect to DB
    db_settings = {"port": os.environ['DATABASE_PORT'], "host": os.environ['DATABASE_HOST'], "password": os.environ['DATABASE_PW'], "user": os.environ['DATABASE_USER'], "database": os.environ['DATABASE_DB']}
    conn = psycopg2.connect(**db_settings)
    print "-Postgres Connected-"
    cur = conn.cursor()

    # Start actions here
    cur.execute("""
        INSERT into datalake.bz_topics (topic)
        select distinct topic
        from datalake.fc_people_topics
        where topic is not null
        group by 1
        on conflict do nothing;

        update datalake.bz_topics
        set topic_cleaned = regexp_replace(topic, '[^a-zA-Z0-9\- ]','','g')
        where topic_cleaned is null;

        update datalake.fc_people_topics
        set bz_topics_id = sq.id
        from (
        	select topic, id
        	from datalake.bz_topics
        ) sq
        where fc_people_topics.topic = sq.topic
        and fc_people_topics.bz_topics_id is null;

        update datalake.bz_topics_articles
        set bz_topics_id = sq.id
        from (
        	select topic, id
        	from datalake.bz_topics
        ) sq
        where bz_topics_articles.topic = sq.topic
        and bz_topics_articles.bz_topics_id is null;
                """)
    conn.commit()

    cur.execute("""
        SELECT topic_cleaned, id
        from datalake.bz_topics
        where last_updated < (now() + INTERVAL '-7 days')
    """)
    topics = cur.fetchall();

    for topic in topics:
        #print(topic[0])
        bs = buzzsumo(topic[0])

        #print bs.status_code

        if bs is not None:
            articles = bs.json()
            for article in articles['results']:
                published_date_converted = time.strftime('%Y-%m-%d', time.localtime(returnVal(article,"published_date")))
                cur.execute("""INSERT INTO datalake.bz_topics_articles ("bz_topics_id","topic","id","total_shares","title","thumbnail","author_name","num_words","total_facebook_shares","giveaway","infographic","guest_post","interview","video","display_title","url","og_url","pinterest_shares","twitter_shares","linkedin_shares","published_date")
                                values (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
                                ON CONFLICT (id) DO NOTHING;
                                """,(topic[1],topic[0],returnVal(article,"id"),returnVal(article,"total_shares"),returnVal(article,"title"),returnVal(article,"thumbnail"),returnVal(article,"author_name"),returnVal(article,"num_words"),returnVal(article,"total_facebook_shares"),returnVal(article,"giveaway"),returnVal(article,"infographic"),returnVal(article,"guest_post"),returnVal(article,"interview"),returnVal(article,"video"),returnVal(article,"display_title"),returnVal(article,"url"),returnVal(article,"og_url"),returnVal(article,"pinterest_shares"),returnVal(article,"twitter_shares"),returnVal(article,"linkedin_shares"),published_date_converted))
                conn.commit()

            # sleep for rate limiting
            hdr = bs.headers
            remaining = float(hdr['X-RateLimit-Remaining'])
            if remaining < 1:
                #print "- Sleeping for Rate Limiting -"
                time.sleep(25)

        cur.execute("""
                    UPDATE datalake.bz_topics
                    set last_updated = now()
                    where id = %s
                    """,(topic[1],))
        conn.commit()


    # close database connection
    print "-Script Finished-"
    conn.close()


if __name__ == "__main__":
    main()
