import psycopg2
import psycopg2.extensions
import os, sys
import requests
from HTMLParser import HTMLParser
from xml.dom import minidom
import re

# html helper
h = HTMLParser()

# xml helper
def getNodeText(node):
    nodelist = node.childNodes
    result = []
    for node in nodelist:
        if node.nodeType == node.TEXT_NODE:
            result.append(node.data)
    return ''.join(result)

def returnTagValue(obj, name):
    if obj.getElementsByTagName(name).length == 0:
        return None
    else:
        if getNodeText(obj.getElementsByTagName(name)[0]) == '':
            return None
        else:
            return h.unescape(getNodeText(obj.getElementsByTagName(name)[0])).encode('utf-8')

def sanitize_text(data):
    #print('type(data): {}'.format(type(data)))
    replace_with = {
        u'\u2018': '\'',
        u'\u2019': '\'',
        u'\u201c': '"',
        u'\u201d': '"'
    }

    bad_chars = [c for c in data if ord(c) >= 127]
    #if bad_chars:
    #    print('INVALID CHARACTERS: {}'.format(bad_chars))
    #else:
    #    print('INVALID CHARACTERS: {}'.format(bad_chars))

    for uni_char in replace_with.keys():
        data = data.replace(uni_char, replace_with.get(uni_char))

    data = ''.join([c for c in data if ord(c) < 127])
    return data.encode('utf-8', 'xmlcharreplace')

# method to call brand24 endpoints
def brand24(endpoint, option):
    base_url = 'https://api.brand24.com/api/'
    site_endpoint = base_url + endpoint + '?aid=' + os.environ['BRAND24_AID'] + '&key=' + os.environ['BRAND24_KEY']
    if option:
        site_endpoint = site_endpoint + '&' + option
    try:
        #print site_endpoint
        r = requests.get(site_endpoint)
        if r.status_code == 200:
            xmltext = sanitize_text(r.text)
            xmltext2 = xmltext.encode('utf-8')
            xmlparsed = minidom.parseString(xmltext2)
            #print(site_endpoint)
            return xmlparsed
        else:
            print('Error connecting to server:' + str(r.status_code))
    except requests.exceptions.RequestException:
        print('Error connecting to server.')
        return None
    except:
        print("Other Error on " + site_endpoint)
        return None

# main method
def main():
    # Connect to DB
    db_settings = {"port": os.environ['DATABASE_PORT'], "host": os.environ['DATABASE_HOST'], "password": os.environ['DATABASE_PW'], "user": os.environ['DATABASE_USER'], "database": os.environ['DATABASE_DB']}
    conn = psycopg2.connect(**db_settings)
    print("-Postgres Connected-")
    cur = conn.cursor()

    # Projects
    projects_xml = brand24("projects","phrases=1")
    for project in projects_xml.getElementsByTagName("project"):
            pid = returnTagValue(project,"id")
            pname = returnTagValue(project,"name")
            cur.execute("""INSERT INTO datalake.b24_projects (id,name)
                            values (%s, %s)
                            ON CONFLICT (id) DO UPDATE SET
                            name=%s;""", (pid,pname,pname))
            conn.commit()

            # Mentions
            if True: #pid == '51168139':
                cur.execute("""select max(id) from datalake.b24_mentions where project_id = %s""",(str(pid),))
                rid = cur.fetchone()[0]
                rid = rid if rid != None else 0
                more = 1

                # Keep looping until the API returns "more=0" as defined in API spec
                while int(more) != 0:
                    project_xml = brand24("results-download",("sid=" + str(pid) + "&rid=" + str(rid)))
                    if project_xml is not None:
                        for mention in project_xml.getElementsByTagName("result"):
                                cur.execute("""INSERT INTO datalake.b24_mentions ("id","url","title","content","sentiment","created_date","category","author","author_url","gender","valuable","estimated_social_reach","project_id")
                                                values (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
                                                ON CONFLICT (id) DO NOTHING;
                                                """, (returnTagValue(mention,"id"),returnTagValue(mention,"url"),returnTagValue(mention,"title"),returnTagValue(mention,"content"),returnTagValue(mention,"sentiment"),returnTagValue(mention,"created_date"),returnTagValue(mention,"category"),returnTagValue(mention,"author"),returnTagValue(mention,"author_url"),returnTagValue(mention,"gender"),returnTagValue(mention,"valuable"),returnTagValue(mention,"estimated_social_reach"),pid))
                                conn.commit()
                        more = project_xml.getElementsByTagName("results")[0].getAttribute("more")
                        cur.execute("""select max(id) from datalake.b24_mentions where project_id = %s""",(str(pid),))
                        rid = cur.fetchone()[0]
                    else:
                        more = 0

    cur.execute("""
                UPDATE datalake.b24_mentions
                SET url_domain = s.urld
                FROM (
                	select id, substring(url from '.*://([^/]*)') as urld
                	from datalake.b24_mentions
                ) s
                WHERE b24_mentions.id = s.id and url_domain is null;
                """)
    conn.commit()

    # close database connection
    print("-Script Finished-")
    conn.close()


if __name__ == "__main__":
    main()
