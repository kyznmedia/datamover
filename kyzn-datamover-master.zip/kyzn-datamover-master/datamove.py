import psycopg2
import psycopg2.extensions
import os

def main():
    # Connect to DB
    db_settings = {"port": os.environ['DATABASE_PORT'], "host": os.environ['DATABASE_HOST'], "password": os.environ['DATABASE_PW'], "user": os.environ['DATABASE_USER'], "database": os.environ['DATABASE_DB']}
    conn = psycopg2.connect(**db_settings)
    print "-Postgres Connected-"
    cur = conn.cursor()

    # Start actions here

    # close database connection
    print "-Script Finished-"
    conn.close()


if __name__ == "__main__":
    main()
