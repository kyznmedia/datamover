import psycopg2
import psycopg2.extensions
import os
import requests
from fullcontact import FullContact
import json
from datetime import datetime, timedelta
import time
import sys

# object helper
def returnVal(obj, name):
    try:
        return obj[name]
    except:
        return None

# main method
def main():
    # Connect to DB
    db_settings = {"port": os.environ['DATABASE_PORT'], "host": os.environ['DATABASE_HOST'], "password": os.environ['DATABASE_PW'], "user": os.environ['DATABASE_USER'], "database": os.environ['DATABASE_DB']}
    conn = psycopg2.connect(**db_settings)
    print("-Postgres Connected-")
    cur = conn.cursor()

    fc = FullContact(os.environ['FC_KEY'])

    cur.execute("""
    select author, pid
    from (
    	select author, status, s.fc_people_id as pid, active
    	from (
    		select distinct author, max(active) as active
    		from datalake.b24_mentions
    		join datalake.b24_projects
    		on b24_mentions.project_id = b24_projects.id
    		where author_url like '%twitter%' and author is not null
    		group by 1
    	) b24
    	left join (
    		select username, fc_people_id
    		from datalake.fc_people_socials
    		where typeid = 'twitter'
    	) s
    	on lower(s.username) = lower(b24.author)
    	left join datalake.fc_people p
    	on p.id = s.fc_people_id
    ) f
    where status <> 200 or status is null and active = 1
    """)
    twitters = cur.fetchall();

    # set up variables
    next_req_time = datetime.fromtimestamp(0)
    i = 0

    # loop through twitters
    for twitter in twitters:
        #sys.stdout.flush()
        #print i
        pid = twitter[1]
        r = fc.person(twitter=twitter[0])
        person = r.json()
        #print(person)

        contactinfo = returnVal(person,"contactInfo")
        socialprofiles = returnVal(person,"socialProfiles")
        demographics = returnVal(person,"demographics")
        digitalfootprint = returnVal(person,"digitalFootprint")
        topics = returnVal(digitalfootprint,"topics")

        if returnVal(person,"status") == 200:
            if pid is None:
                cur.execute("""insert into datalake.fc_people ("status", "request") values (%s,%s);""",(returnVal(person,"status"),returnVal(person,"requestId")))
                conn.commit()
                cur.execute("""select id from datalake.fc_people where request = %s""",(returnVal(person,"requestId"),))
                pid = cur.fetchone()[0]

            cur.execute("""
                update datalake.fc_people set
                    "status" = %s,
                    "request" = %s,
                    "familyName" = %s,
                    "givenName" = %s,
                    "fullName" = %s,
                    "locationGeneral" = %s,
                    "deducedLocation" = %s,
                    "deducedCity" = %s,
                    "deducedState" = %s,
                    "deducedCountry" = %s,
                    "deducedContinent" = %s,
                    "deducedCounty" = %s,
                    "age" = %s,
                    "gender" = %s,
                    "ageRange"  = %s
                where id = %s
                ;""",(
                    returnVal(person,"status"),
                    returnVal(person,"requestId"),
                    returnVal(contactinfo,"familyName"),
                    returnVal(contactinfo,"givenName"),
                    returnVal(contactinfo,"fullName"),
                    returnVal(demographics,"locationGeneral"),
                    returnVal(returnVal(demographics,"locationsDeduceed"),"deducedLocation"),
                    returnVal(returnVal(returnVal(demographics,"locationsDeduceed"),"city"),"name"),
                    returnVal(returnVal(returnVal(demographics,"locationsDeduceed"),"state"),"name"),
                    returnVal(returnVal(returnVal(demographics,"locationsDeduceed"),"country"),"name"),
                    returnVal(returnVal(returnVal(demographics,"locationsDeduceed"),"continent"),"name"),
                    returnVal(returnVal(returnVal(demographics,"locationsDeduceed"),"county"),"name"),
                    returnVal(demographics,"age"),
                    returnVal(demographics,"gender"),
                    returnVal(demographics,"ageRange"),
                    pid))
            conn.commit()

            if socialprofiles is not None:
                for social in socialprofiles:
                    #print social
                    cur.execute("""
                        insert into datalake.fc_people_socials (
                        "id",
                        "typeid",
                        "url",
                        "username",
                        "bio",
                        "following",
                        "followers",
                        "typename",
                        "rss",
                        "fc_people_id")
                        values (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)
                        on conflict do nothing;""",(
                            returnVal(social,"id"),
                            returnVal(social,"typeId"),
                            returnVal(social,"url"),
                            returnVal(social,"username"),
                            returnVal(social,"bio"),
                            returnVal(social,"following"),
                            returnVal(social,"followers"),
                            returnVal(social,"typename"),
                            returnVal(social,"rss"),
                            pid
                        ))
                    conn.commit()

            if topics is not None:
                for topic in topics:
                    #print topic
                    cur.execute("""
                        insert into datalake.fc_people_topics (
                        "topic",
                        "source",
                        "fc_people_id")
                        values (%s,%s,%s)
                        on conflict do nothing;""",(
                            returnVal(topic,"value"),
                            returnVal(topic,"provider"),
                            pid
                        ))
                    conn.commit()

        # sleep if running out of wait time
        hdr = r.headers
        remaining = float(hdr['X-Rate-Limit-Remaining'])
        reset = float(hdr['X-Rate-Limit-Reset'])
        spacing = reset / (1.0 + remaining)
        delay = spacing - 0.2
        next_req_time = datetime.now() + timedelta(seconds=delay)
        now = datetime.now()
        if next_req_time > now:
            #print "- Sleeping for Rate Limiting -"
            t = next_req_time - now
            time.sleep(t.total_seconds())
        i = i + 1

    cur.execute("""
        UPDATE datalake.b24_mentions
        SET fc_people_id = s.fc_people_id
        FROM (
        	select username, fc_people_id
        	from datalake.fc_people_socials
        	where typeid = 'twitter'
        ) s
        WHERE lower(b24_mentions.author) = (s.username)
        and b24_mentions.fc_people_id is null;
    """)
    conn.commit()

    # close database connection
    print("-Script Finished-")
    conn.close()


if __name__ == "__main__":
    main()
